package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class CartridgeManufacturer {

    @FXML
    private JFXButton cancel;

    @FXML
    private JFXTextField man_phone;

    @FXML
    private JFXButton submit;

    @FXML
    private JFXTextField man_zip;

    @FXML
    private JFXTextField man_state;

    @FXML
    private JFXComboBox<?> man_status;

    @FXML
    private JFXTextField man_id;

    @FXML
    private JFXTextField man_city;

    @FXML
    private Text title;

    @FXML
    private JFXTextField man_address;

    @FXML
    private JFXTextField man_name;

    @FXML
    void makesubmit(ActionEvent event) {

    }

    @FXML
    void makecancel(ActionEvent event) {

    }

    /*@FXML
    void 4059

    CartridgeManufacturer(ActionEvent event) {

    }*/

}
